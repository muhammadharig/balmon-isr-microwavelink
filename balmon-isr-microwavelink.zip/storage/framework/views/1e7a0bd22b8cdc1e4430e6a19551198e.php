<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="card">
            <h5 class="card-header">Data Users</h5>
            <div class="card-body">
                <div class="d-flex align-items-start align-items-sm-center gap-4 mb-3">
                    <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary"> <i class="fas fa-plus"></i>Add New
                        User</a>
                </div>
                <div class="table-responsive text-nowrap">
                    <table class="table table-striped" id="tbl-users">
                        <thead>
                            <tr class="bg-dark">
                                <th class="text-white">No</th>
                                <th class="text-white">Photo</th>
                                <th class="text-white">Name</th>
                                <th class="text-white">Email</th>
                                <th class="text-white">Phone</th>
                                <th class="text-white">Role</th>
                                <th class="text-white">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td class="text-center">
                                        <?php if($user->photo == null): ?>
                                            <img src="<?php echo e(asset('sneat')); ?>/assets/img/avatars/user.jpg"
                                                class="w-px-40 h-auto rounded-circle" alt="Avatar">
                                        <?php elseif($user->photo != null): ?>
                                            <img src="<?php echo e(asset('storage/photos/' . $user->photo)); ?>"
                                                class="w-px-40 h-auto rounded-circle" width="50">
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->phone); ?></td>
                                    <td>
                                        <?php if($user->role == 'user'): ?>
                                            <span class="badge bg-dark"><?php echo e($user->role); ?></span>
                                        <?php elseif($user->role == 'operator'): ?>
                                            <span class="badge bg-primary"><?php echo e($user->role); ?></span>
                                        <?php elseif($user->role == 'pimpinan'): ?>
                                            <span class="badge bg-success"><?php echo e($user->role); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <div class="btn-group" role="group">
                                            <a href="<?php echo e(route('users.edit', $user->id)); ?>"
                                                class="btn btn-warning btn-sm mx-2"><i class="fas fa-edit"></i> Edit</a>
                                            <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST">
                                                <input type="hidden" name="_method" value="DELETE" />
                                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                                                <button class="btn btn-danger btn-sm"><i class="fas fa-trash"></i>
                                                    Delete</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'Users'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\development\balmon-isr-microwavelink\resources\views/pages/users/index.blade.php ENDPATH**/ ?>