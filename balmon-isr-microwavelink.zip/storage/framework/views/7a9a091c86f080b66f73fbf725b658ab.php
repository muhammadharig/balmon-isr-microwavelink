<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="card mb-4">
            <h5 class="card-header">Filter Statistik</h5>
            <div class="card-body">
                <form action="#" method="GET">
                    <div class="row gx-3 gy-2 align-items-center">
                        <div class="col-md-3">
                            <label class="form-label" for="selectTypeOpt">Bulan</label>
                            <select class="form-select color-dropdown" name="bulan">
                                <option value="01" <?php echo e($bulan == '01' ? 'selected' : ''); ?>>Januari</option>
                                <option value="02" <?php echo e($bulan == '02' ? 'selected' : ''); ?>>Februari</option>
                                <option value="03" <?php echo e($bulan == '03' ? 'selected' : ''); ?>>Maret</option>
                                <option value="04" <?php echo e($bulan == '04' ? 'selected' : ''); ?>>April</option>
                                <option value="05" <?php echo e($bulan == '05' ? 'selected' : ''); ?>>Mei</option>
                                <option value="06" <?php echo e($bulan == '06' ? 'selected' : ''); ?>>Juni</option>
                                <option value="07" <?php echo e($bulan == '07' ? 'selected' : ''); ?>>Juli</option>
                                <option value="08" <?php echo e($bulan == '08' ? 'selected' : ''); ?>>Agustus</option>
                                <option value="09" <?php echo e($bulan == '09' ? 'selected' : ''); ?>>September</option>
                                <option value="10" <?php echo e($bulan == '10' ? 'selected' : ''); ?>>Oktober</option>
                                <option value="11" <?php echo e($bulan == '11' ? 'selected' : ''); ?>>November</option>
                                <option value="12" <?php echo e($bulan == '12' ? 'selected' : ''); ?>>Desember</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Tahun</label>
                            <select class="form-select" name="tahun">
                                <?php $__currentLoopData = $tahuns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahunOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tahunOption); ?>"
                                        <?php echo e(old('tahun', $tahun) == $tahunOption ? 'selected' : ''); ?>><?php echo e($tahunOption); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label" for="showToastPlacement">&nbsp;</label>
                            <button class="btn btn-primary d-block">Filter</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="card">
                <h5 class="card-header m-0 me-2 pb-3 text-center">Statistik ISR</h5>
                <div class="px-4" style="position: relative; margin:auto; height:40vh; width:80vw">
                    <canvas id="isrChart"></canvas>
                </div>
            </div>
        </div>
    </div>
    <script>
        $(function() {
            var ctx = document.getElementById("isrChart").getContext('2d');
            var data = <?php echo json_encode($data); ?>;
            var labels = <?php echo json_encode($labels); ?>;
            var data = {
                datasets: [{
                    data: data,
                    label: 'Total',
                }],
                labels: labels
            };
            var isrBarChart = new Chart(ctx, {
                type: 'bar',
                data: data,
                options: {
                    maintainAspectRatio: false,
                    legend: {
                        position: 'bottom',
                        labels: {
                            boxWidth: 12
                        }
                    }
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'ISR'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\development\balmon-isr-microwavelink\resources\views/pages/isr/index.blade.php ENDPATH**/ ?>