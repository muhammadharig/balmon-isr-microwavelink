<?php if(session()->has('success')): ?>
    <script>
        iziToast.success({
            title: "Berhasil!",
            message: "<?php echo e(session('success')); ?>",
            position: "topRight",
        });
    </script>
<?php endif; ?>
<?php if(session()->has('error')): ?>
    <script>
        iziToast.error({
            title: "Gagal!",
            message: "<?php echo e(session('error')); ?>",
            position: "topRight",
        });
    </script>
<?php endif; ?>
<?php /**PATH D:\development\balmon-isr-microwavelink\resources\views/components/alert.blade.php ENDPATH**/ ?>