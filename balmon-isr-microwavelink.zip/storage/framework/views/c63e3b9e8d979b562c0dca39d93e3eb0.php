<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="modal modal-top fade" id="modalTop" tabindex="-1">
            <div class="modal-dialog">
                <form action="<?php echo e(route('microwavelinks.import')); ?>" method="POST" enctype="multipart/form-data"
                    class="modal-content">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalTopTitle">Import Data Microwavelink</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group mb-3">
                            <label for="">Pilih File</label>
                            <input type="file" class="form-control" name="import_file">
                        </div>
                        <button type="submit" class="btn btn-primary"><i class="fas fa-upload"></i>
                            Import File
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <div class="card">
            <h5 class="card-header">Data Microwavelink</h5>
            <div class="card-body">
                <div class="d-flex align-items-start align-items-sm-center gap-4 mb-3">
                    <!-- Button trigger modal -->
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalTop"><i
                            class="fas fa-upload"></i>
                        Import
                    </button>
                </div>
                <div class="table-responsive text-nowrap">
                    <table class="table table-bordered" id="tbl-bc">
                        <thead>
                            <tr class="bg-dark">
                                <th class="text-white">No</th>
                                <th class="text-white">CURR_LIC_NUM</th>
                                <th class="text-white">CLNT_ID</th>
                                <th class="text-white">APPL_ID</th>
                                <th class="text-white">ERP_PWR_DBM</th>
                                <th class="text-white">BWIDTH</th>
                                <th class="text-white">BHP</th>
                                <th class="text-white">EQ_MDL</th>
                                <th class="text-white">ANT_MDL</th>
                                <th class="text-white">HGT_ANT</th>
                                <th class="text-white">MASTER_PLZN_CODE</th>
                                <th class="text-white">SID_LONG</th>
                                <th class="text-white">SID_LAT</th>
                                <th class="text-white">MON_QURY</th>
                                <th class="text-white">ACTION</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $microwavelinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($column->curr_lic_num); ?></td>
                                    <td><?php echo e($column->clnt_id); ?></td>
                                    <td><?php echo e($column->appl_id); ?></td>
                                    <td><?php echo e($column->erp_pwr_dbm); ?></td>
                                    <td><?php echo e($column->bwidth); ?></td>
                                    <td><?php echo e($column->bhp); ?></td>
                                    <td><?php echo e($column->eq_mdl); ?></td>
                                    <td><?php echo e($column->ant_mdl); ?></td>
                                    <td><?php echo e($column->hgt_ant); ?></td>
                                    <td><?php echo e($column->master_plzn_code); ?></td>
                                    <td><?php echo e($column->sid_long); ?></td>
                                    <td><?php echo e($column->sid_lat); ?></td>
                                    <td><?php echo e($column->mon_query); ?></td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <a href="<?php echo e(route('microwavelinks.edit', $column->id)); ?>"
                                                class="btn btn-warning btn-sm mx-2"><i class="fas fa-edit"></i> Edit</a>
                                            <form action="<?php echo e(route('microwavelinks.destroy', $column->id)); ?>"
                                                method="POST">
                                                <input type="hidden" name="_method" value="DELETE" />
                                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                                                <button class="btn btn-danger btn-sm"><i class="fas fa-trash"></i>
                                                    Delete</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'Microwavelink'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\development\balmon-isr-microwavelink\resources\views/pages/microwavelink/index.blade.php ENDPATH**/ ?>